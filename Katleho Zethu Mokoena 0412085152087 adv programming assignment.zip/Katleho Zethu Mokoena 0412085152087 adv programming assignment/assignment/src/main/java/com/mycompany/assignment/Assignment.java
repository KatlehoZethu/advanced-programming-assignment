package com.mycompany.assignment;

public class Assignment {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
